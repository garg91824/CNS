RSA-Library
===========

This is a C library for RSA encryption. It provides three functions for key generation, encryption, and decryption.
Detailed descriptions of these functions are provided in the header file rsa.h.

Created by Andrew Kiluk
